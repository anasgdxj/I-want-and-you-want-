import { useCallback, useEffect, useMemo, useState } from 'react';
import { Loader2, Search, ShieldAlert } from 'lucide-react';
import Navbar from './components/Navbar';
import ListingCard from './components/ListingCard';
import AddListingModal from './components/AddListingModal';
import SwapModal from './components/SwapModal';
import { supabase } from './lib/supabase';
import { getErrorMessage } from './lib/utils';
import { CATEGORIES, OFFER_TYPES, SYRIAN_CITIES, type Listing, type OfferType } from './types';

const CACHE_KEY = 'bw-bd-listings-cache';

const DEMO_LISTINGS: Listing[] = [
  {
    id: 'demo-1',
    created_at: '2026-11-20T10:00:00Z',
    title: 'كتب طب سنة أولى - كاملة',
    description: 'كتب تشريح وفيزيولوجيا بحالة ممتازة، بدون تظهير.',
    category: 'books',
    city: 'دمشق',
    neighborhood: 'المزرعة',
    offer_type: 'both',
    price_syp: 150000,
    swap_preference: 'كتب طب سنة ثانية أو آلة حاسبة علمية',
    accepts_cash_diff: true,
    condition: 'like_new',
    image_url: null,
    contact_name: 'سامر',
    contact_phone: '0944000001',
    status: 'active',
  },
  {
    id: 'demo-2',
    created_at: '2026-11-19T12:00:00Z',
    title: 'طاولة خشب مع أربعة كراسي',
    description: 'مستعملة، بحالة جيدة. تحتاج تنظيف بسيط.',
    category: 'home',
    city: 'حلب',
    neighborhood: 'الجميلية',
    offer_type: 'gift',
    price_syp: null,
    swap_preference: null,
    accepts_cash_diff: false,
    condition: 'fair',
    image_url: null,
    contact_name: 'ريم',
    contact_phone: '0933000002',
    status: 'active',
  },
  {
    id: 'demo-3',
    created_at: '2026-11-18T09:00:00Z',
    title: 'لابتوب قديم للدراسة',
    description: 'يعمل بشكل ممتاز، بطارية تكفي ساعتين تقريباً.',
    category: 'electronics',
    city: 'اللاذقية',
    neighborhood: null,
    offer_type: 'swap',
    price_syp: null,
    swap_preference: 'تابلت أو ساعة ذكية',
    accepts_cash_diff: true,
    condition: 'good',
    image_url: null,
    contact_name: 'يوسف',
    contact_phone: '0988000003',
    status: 'active',
  },
  {
    id: 'demo-4',
    created_at: '2026-11-17T15:00:00Z',
    title: 'عربة أطفال وملابس شتوية',
    description: 'عربة نظيفة مع ثلاث بدلات شتوية لعمر سنتين.',
    category: 'kids',
    city: 'حمص',
    neighborhood: 'الإنشاءات',
    offer_type: 'sell',
    price_syp: 400000,
    swap_preference: null,
    accepts_cash_diff: false,
    condition: 'good',
    image_url: null,
    contact_name: 'لينا',
    contact_phone: '0955000004',
    status: 'active',
  },
];

function readCache(): Listing[] {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as Listing[]) : [];
  } catch {
    return [];
  }
}

export default function App() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('');
  const [category, setCategory] = useState('');
  const [offerType, setOfferType] = useState<'' | OfferType>('');
  const [showAdd, setShowAdd] = useState(false);
  const [swapFor, setSwapFor] = useState<Listing | null>(null);

  const loadListings = useCallback(async () => {
    setLoading(true);

    if (!supabase) {
      setListings(DEMO_LISTINGS);
      setNotice('التطبيق يعمل في وضع التجربة. أضف متغيرات Supabase لتفعيل الإعلانات الحقيقية.');
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('listings')
        .select('*')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(200);
      if (error) throw error;

      const rows = (data ?? []) as Listing[];
      setListings(rows);
      setNotice(null);
      try {
        localStorage.setItem(CACHE_KEY, JSON.stringify(rows));
      } catch {
        // storage full or disabled: ignore
      }
    } catch (err) {
      const cached = readCache();
      if (cached.length > 0) {
        setListings(cached);
        setNotice('لا يوجد اتصال حالياً، تُعرض آخر الإعلانات المحفوظة على جهازك.');
      } else {
        setListings([]);
        setNotice(`تعذر تحميل الإعلانات: ${getErrorMessage(err)}`);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadListings();
  }, [loadListings]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return listings.filter((l) => {
      if (city && l.city !== city) return false;
      if (category && l.category !== category) return false;
      if (offerType && l.offer_type !== offerType) return false;
      if (q) {
        const haystack = `${l.title} ${l.description ?? ''} ${l.neighborhood ?? ''}`.toLowerCase();
        if (!haystack.includes(q)) return false;
      }
      return true;
    });
  }, [listings, query, city, category, offerType]);

  const handleCreated = (listing: Listing) => {
    setListings((prev) => [listing, ...prev]);
    setNotice(null);
  };

  return (
    <div className="min-h-screen pb-10">
      <Navbar onAddClick={() => setShowAdd(true)} />

      <main className="mx-auto max-w-6xl px-4 pt-6">
        <section className="mb-6 rounded-2xl bg-gradient-to-l from-emerald-600 to-emerald-800 p-6 text-white shadow">
          <h2 className="text-2xl font-extrabold">بدّي وبدّك</h2>
          <p className="mt-2 text-sm text-emerald-50">
            بدّك شي ومعك شي؟ قايض، بيع، أو أهدِ أغراضك المستعملة لغيرك في سوريا.
          </p>
        </section>

        <div className="mb-6 grid gap-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-sm sm:grid-cols-2 lg:grid-cols-4">
          <div className="relative sm:col-span-2 lg:col-span-1">
            <Search size={18} className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن غرض..."
              className="w-full rounded-xl border border-stone-300 py-2 pe-3 ps-10 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200"
            />
          </div>
          <select value={city} onChange={(e) => setCity(e.target.value)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
            <option value="">كل المحافظات</option>
            {SYRIAN_CITIES.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
            <option value="">كل التصنيفات</option>
            {CATEGORIES.map((c) => (
              <option key={c.value} value={c.value}>{c.label}</option>
            ))}
          </select>
          <select value={offerType} onChange={(e) => setOfferType(e.target.value as '' | OfferType)} className="rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm">
            <option value="">كل أنواع العروض</option>
            {OFFER_TYPES.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {notice && <div className="mb-6 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">{notice}</div>}

        {loading ? (
          <div className="flex items-center justify-center py-20 text-stone-500">
            <Loader2 className="animate-spin" size={28} />
          </div>
        ) : filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-stone-300 bg-white py-16 text-center">
            <p className="font-bold text-stone-700">ما في إعلانات تطابق بحثك</p>
            <p className="mt-1 text-sm text-stone-500">جرّب تغيير الفلاتر، أو أضف غرضك أنت.</p>
          </div>
        ) : (
          <>
            <p className="mb-3 text-sm text-stone-500">{filtered.length} إعلان</p>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((listing) => (
                <ListingCard key={listing.id} listing={listing} onSwap={setSwapFor} />
              ))}
            </div>
          </>
        )}

        <footer className="mt-12 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
          <ShieldAlert size={20} className="mt-0.5 shrink-0" />
          <p>
            نصيحة أمان: قابل الشخص في مكان عام، افحص الغرض قبل أي تبادل، ولا تُرسل أي مبلغ مقدّم قبل الاستلام.
          </p>
        </footer>
      </main>

      {showAdd && <AddListingModal onClose={() => setShowAdd(false)} onCreated={handleCreated} />}
      {swapFor && <SwapModal listing={swapFor} onClose={() => setSwapFor(null)} />}
    </div>
  );
}
