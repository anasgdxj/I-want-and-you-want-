import { Plus, Repeat } from 'lucide-react';

interface NavbarProps {
  onAddClick: () => void;
}

export default function Navbar({ onAddClick }: NavbarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-stone-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white">
            <Repeat size={20} />
          </div>
          <div>
            <h1 className="text-lg font-extrabold leading-tight text-stone-900">بدّي وبدّك</h1>
            <p className="text-xs text-stone-500">مقايضة • بيع • إهداء</p>
          </div>
        </div>
        <button
          type="button"
          onClick={onAddClick}
          className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-4 py-2 text-sm font-bold text-white hover:bg-emerald-700"
        >
          <Plus size={18} />
          أضف غرضك
        </button>
      </div>
    </header>
  );
}
