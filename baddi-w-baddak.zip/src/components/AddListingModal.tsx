import { useState, type FormEvent, type ReactNode } from 'react';
import { Loader2, Upload, X } from 'lucide-react';
import { CATEGORIES, CONDITIONS, OFFER_TYPES, SYRIAN_CITIES, type Condition, type Listing, type OfferType } from '../types';
import { LISTING_IMAGES_BUCKET, supabase } from '../lib/supabase';
import { getErrorMessage } from '../lib/utils';

interface AddListingModalProps {
  onClose: () => void;
  onCreated: (listing: Listing) => void;
}

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

const inputCls =
  'w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200';

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div>
      <label className="mb-1 block text-sm font-semibold text-stone-700">{label}</label>
      {children}
    </div>
  );
}

export default function AddListingModal({ onClose, onCreated }: AddListingModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [offerType, setOfferType] = useState<OfferType>('sell');
  const [category, setCategory] = useState<string>(CATEGORIES[0].value);
  const [condition, setCondition] = useState<Condition>('good');
  const [priceSyp, setPriceSyp] = useState('');
  const [swapPreference, setSwapPreference] = useState('');
  const [acceptsCashDiff, setAcceptsCashDiff] = useState(false);
  const [city, setCity] = useState<string>(SYRIAN_CITIES[0]);
  const [neighborhood, setNeighborhood] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const showPrice = offerType === 'sell' || offerType === 'both';
  const showSwap = offerType === 'swap' || offerType === 'both';

  const handleFile = (selected: File | null) => {
    if (selected && selected.size > MAX_IMAGE_BYTES) {
      setError('حجم الصورة يجب ألا يتجاوز 5 ميغابايت');
      setFile(null);
      return;
    }
    setError(null);
    setFile(selected);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (title.trim().length < 2) {
      setError('الرجاء كتابة عنوان واضح للغرض');
      return;
    }
    if (!contactName.trim() || contactPhone.replace(/\D/g, '').length < 9) {
      setError('الرجاء إدخال اسم ورقم هاتف صحيح');
      return;
    }

    let price: number | null = null;
    if (showPrice && priceSyp.trim()) {
      price = Number(priceSyp);
      if (Number.isNaN(price) || price < 0) {
        setError('السعر غير صحيح');
        return;
      }
    }

    setSaving(true);
    try {
      let imageUrl: string | null = null;
      if (file) {
        if (supabase) {
          const ext = (file.name.split('.').pop() || 'jpg').toLowerCase();
          const path = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}.${ext}`;
          const { error: uploadError } = await supabase.storage
            .from(LISTING_IMAGES_BUCKET)
            .upload(path, file, { contentType: file.type || 'image/jpeg', upsert: false });
          if (uploadError) throw uploadError;
          imageUrl = supabase.storage.from(LISTING_IMAGES_BUCKET).getPublicUrl(path).data.publicUrl;
        } else {
          imageUrl = URL.createObjectURL(file);
        }
      }

      const payload = {
        title: title.trim(),
        description: description.trim() || null,
        category,
        city,
        neighborhood: neighborhood.trim() || null,
        offer_type: offerType,
        price_syp: price,
        swap_preference: showSwap ? swapPreference.trim() || null : null,
        accepts_cash_diff: showSwap && acceptsCashDiff,
        condition,
        image_url: imageUrl,
        contact_name: contactName.trim(),
        contact_phone: contactPhone.trim(),
        status: 'active' as const,
      };

      if (supabase) {
        const { data, error: insertError } = await supabase.from('listings').insert(payload).select().single();
        if (insertError) throw insertError;
        onCreated(data as Listing);
      } else {
        onCreated({ id: `local-${Date.now()}`, created_at: new Date().toISOString(), ...payload });
      }
      onClose();
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 sm:items-center sm:p-4">
      <div className="max-h-[94vh] w-full overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:max-w-lg sm:rounded-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-extrabold text-stone-900">أضف غرضك</h2>
          <button type="button" onClick={onClose} className="rounded-lg p-1 text-stone-500 hover:bg-stone-100" aria-label="إغلاق">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <Field label="عنوان الغرض">
            <input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: كتب طب سنة أولى" />
          </Field>

          <Field label="الوصف - اختياري">
            <textarea className={inputCls} rows={3} value={description} onChange={(e) => setDescription(e.target.value)} />
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="نوع العرض">
              <select className={inputCls} value={offerType} onChange={(e) => setOfferType(e.target.value as OfferType)}>
                {OFFER_TYPES.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
            </Field>
            <Field label="التصنيف">
              <select className={inputCls} value={category} onChange={(e) => setCategory(e.target.value)}>
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>{c.label}</option>
                ))}
              </select>
            </Field>
          </div>

          <Field label="الحالة">
            <select className={inputCls} value={condition} onChange={(e) => setCondition(e.target.value as Condition)}>
              {CONDITIONS.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </Field>

          {showPrice && (
            <Field label="السعر بالليرة السورية (ل.س)">
              <input className={inputCls} type="number" min={0} dir="ltr" value={priceSyp} onChange={(e) => setPriceSyp(e.target.value)} />
            </Field>
          )}

          {showSwap && (
            <>
              <Field label="بدّي مقابله">
                <input className={inputCls} value={swapPreference} onChange={(e) => setSwapPreference(e.target.value)} placeholder="مثال: كتب إنكليزية أو جهاز لوحي" />
              </Field>
              <label className="flex items-center gap-2 text-sm text-stone-700">
                <input type="checkbox" checked={acceptsCashDiff} onChange={(e) => setAcceptsCashDiff(e.target.checked)} className="h-4 w-4 accent-emerald-600" />
                أقبل فرق نقدي مع المقايضة
              </label>
            </>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="المحافظة">
              <select className={inputCls} value={city} onChange={(e) => setCity(e.target.value)}>
                {SYRIAN_CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </Field>
            <Field label="الحي - اختياري">
              <input className={inputCls} value={neighborhood} onChange={(e) => setNeighborhood(e.target.value)} />
            </Field>
          </div>

          <Field label="صورة الغرض - اختياري (حتى 5 ميغابايت)">
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-stone-300 p-4 text-sm text-stone-600 hover:border-emerald-500">
              <Upload size={18} />
              {file ? file.name : 'اختر صورة'}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleFile(e.target.files?.[0] ?? null)} />
            </label>
          </Field>

          <div className="grid grid-cols-2 gap-3">
            <Field label="اسمك">
              <input className={inputCls} value={contactName} onChange={(e) => setContactName(e.target.value)} />
            </Field>
            <Field label="رقم الهاتف">
              <input className={inputCls} inputMode="tel" dir="ltr" placeholder="09XXXXXXXX" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} />
            </Field>
          </div>

          {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{error}</p>}

          <button
            type="submit"
            disabled={saving}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 font-bold text-white hover:bg-emerald-700 disabled:opacity-60"
          >
            {saving && <Loader2 size={18} className="animate-spin" />}
            نشر الإعلان
          </button>
        </form>
      </div>
    </div>
  );
}
