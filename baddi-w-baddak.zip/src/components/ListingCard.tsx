import { MapPin, MessageCircle, Package, Phone, Repeat } from 'lucide-react';
import type { Listing, OfferType } from '../types';
import { formatSYP, normalizeSyrianPhone } from '../lib/utils';

const BADGES: Record<OfferType, { label: string; className: string }> = {
  sell: { label: 'بيع', className: 'bg-blue-100 text-blue-800' },
  swap: { label: 'للمقايضة', className: 'bg-amber-100 text-amber-800' },
  both: { label: 'بيع أو مقايضة', className: 'bg-violet-100 text-violet-800' },
  gift: { label: 'إهداء مجاني', className: 'bg-rose-100 text-rose-800' },
};

interface ListingCardProps {
  listing: Listing;
  onSwap: (listing: Listing) => void;
}

export default function ListingCard({ listing, onSwap }: ListingCardProps) {
  const badge = BADGES[listing.offer_type];
  const phone = normalizeSyrianPhone(listing.contact_phone);
  const canSwap = listing.offer_type === 'swap' || listing.offer_type === 'both';
  const hasPrice = (listing.offer_type === 'sell' || listing.offer_type === 'both') && listing.price_syp !== null;
  const waText = encodeURIComponent(
    `مرحباً ${listing.contact_name}، أنا مهتم بإعلانك "${listing.title}" على بدّي وبدّك.`,
  );

  let priceText = 'السعر قابل للتفاوض';
  if (listing.offer_type === 'gift') priceText = 'مجاناً';
  else if (hasPrice) priceText = formatSYP(listing.price_syp as number);
  else if (listing.offer_type === 'swap') priceText = 'مقايضة فقط';

  return (
    <article className="flex flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm transition hover:shadow-md">
      <div className="relative aspect-[4/3] bg-stone-100">
        {listing.image_url ? (
          <img src={listing.image_url} alt={listing.title} loading="lazy" className="h-full w-full object-cover" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-stone-300">
            <Package size={48} />
          </div>
        )}
        <span className={`absolute right-3 top-3 rounded-full px-3 py-1 text-xs font-bold ${badge.className}`}>
          {badge.label}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div>
          <h3 className="line-clamp-2 text-base font-bold text-stone-900">{listing.title}</h3>
          <p className="mt-1 flex items-center gap-1 text-xs text-stone-500">
            <MapPin size={13} />
            {listing.city}
            {listing.neighborhood ? ` • ${listing.neighborhood}` : ''}
          </p>
        </div>

        <div className="text-lg font-extrabold text-emerald-700">{priceText}</div>

        {canSwap && (
          <div className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
            <p className="flex items-center gap-1.5 font-semibold">
              <Repeat size={15} />
              بدّي مقابله: {listing.swap_preference || 'اعرض عليّ ما عندك'}
            </p>
            {listing.accepts_cash_diff && <p className="mt-1 text-xs">يُقبل فرق نقدي مع المقايضة</p>}
          </div>
        )}

        <div className="mt-auto flex flex-col gap-2 pt-2">
          {canSwap && (
            <button
              type="button"
              onClick={() => onSwap(listing)}
              className="w-full rounded-xl border border-emerald-600 px-3 py-2 text-sm font-bold text-emerald-700 hover:bg-emerald-50"
            >
              اقترح مقايضة
            </button>
          )}
          <div className="grid grid-cols-2 gap-2">
            <a
              href={`tel:+${phone}`}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-stone-900 px-3 py-2 text-sm font-semibold text-white hover:bg-stone-700"
            >
              <Phone size={16} />
              اتصال
            </a>
            <a
              href={`https://wa.me/${phone}?text=${waText}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 rounded-xl bg-green-600 px-3 py-2 text-sm font-semibold text-white hover:bg-green-700"
            >
              <MessageCircle size={16} />
              واتساب
            </a>
          </div>
        </div>
      </div>
    </article>
  );
}
