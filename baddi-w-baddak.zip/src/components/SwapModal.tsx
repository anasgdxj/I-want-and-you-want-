import { useState, type FormEvent } from 'react';
import { ExternalLink, Loader2, Send, X } from 'lucide-react';
import type { Listing } from '../types';
import { supabase } from '../lib/supabase';
import { formatSYP, getErrorMessage, normalizeSyrianPhone } from '../lib/utils';

interface SwapModalProps {
  listing: Listing;
  onClose: () => void;
}

const inputCls =
  'w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm focus:border-emerald-500 focus:outline-none focus:ring-2 focus:ring-emerald-200';

export default function SwapModal({ listing, onClose }: SwapModalProps) {
  const [proposerName, setProposerName] = useState('');
  const [proposerPhone, setProposerPhone] = useState('');
  const [offeredItem, setOfferedItem] = useState('');
  const [cashDiff, setCashDiff] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [waUrl, setWaUrl] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!proposerName.trim() || proposerPhone.replace(/\D/g, '').length < 9 || !offeredItem.trim()) {
      setError('الرجاء تعبئة اسمك ورقم هاتفك وتسمية الغرض الذي تعرضه');
      return;
    }

    const cash = cashDiff.trim() ? Number(cashDiff) : null;
    if (cash !== null && (Number.isNaN(cash) || cash < 0)) {
      setError('فرق السعر غير صحيح');
      return;
    }

    setSaving(true);
    try {
      if (supabase) {
        const { error: insertError } = await supabase.from('swap_offers').insert({
          listing_id: listing.id,
          proposer_name: proposerName.trim(),
          proposer_phone: proposerPhone.trim(),
          offered_item_title: offeredItem.trim(),
          cash_diff_syp: cash,
          notes: notes.trim() || null,
          status: 'pending',
        });
        if (insertError) throw insertError;
      }

      const lines = [
        `مرحباً ${listing.contact_name}، أنا ${proposerName.trim()}.`,
        `أقترح مقايضة على "${listing.title}" بـ "${offeredItem.trim()}"${
          cash ? ` مع فرق نقدي ${formatSYP(cash)}` : ''
        }.`,
        notes.trim() ? `ملاحظة: ${notes.trim()}` : '',
        `رقم التواصل: ${proposerPhone.trim()}`,
        '(عبر بدّي وبدّك)',
      ].filter(Boolean);

      setWaUrl(
        `https://wa.me/${normalizeSyrianPhone(listing.contact_phone)}?text=${encodeURIComponent(lines.join('\n'))}`,
      );
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-4">
      <div className="max-h-[92vh] w-full overflow-y-auto rounded-t-2xl bg-white p-5 shadow-xl sm:max-w-md sm:rounded-2xl">
        <div className="mb-4 flex items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-extrabold text-stone-900">اقتراح مقايضة</h2>
            <p className="text-sm text-stone-500 line-clamp-1">على: {listing.title}</p>
          </div>
          <button type="button" onClick={onClose} className="rounded-lg p-1 text-stone-500 hover:bg-stone-100" aria-label="إغلاق">
            <X size={20} />
          </button>
        </div>

        {waUrl ? (
          <div className="space-y-4">
            <p className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-900">
              تم تجهيز اقتراحك. افتح واتساب لإرساله لصاحب الغرض.
            </p>
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 px-4 py-3 font-bold text-white hover:bg-green-700"
            >
              <ExternalLink size={18} />
              افتح واتساب وأرسل الرسالة
            </a>
            <button type="button" onClick={onClose} className="w-full rounded-xl border border-stone-300 py-2 text-sm font-semibold text-stone-700">
              إغلاق
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="mb-1 block text-sm font-semibold text-stone-700">اسمك</label>
              <input className={inputCls} value={proposerName} onChange={(e) => setProposerName(e.target.value)} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-stone-700">رقم هاتفك</label>
              <input className={inputCls} inputMode="tel" dir="ltr" placeholder="09XXXXXXXX" value={proposerPhone} onChange={(e) => setProposerPhone(e.target.value)} />
            </div>
            <div>
              <label className="mb-1 block text-sm font-semibold text-stone-700">الغرض الذي تعرضه للمقايضة</label>
              <input className={inputCls} value={offeredItem} onChange={(e) => setOfferedItem(e.target.value)} />
            </div>
            {listing.accepts_cash_diff && (
              <div>
                <label className="mb-1 block text-sm font-semibold text-stone-700">فرق نقدي تعرضه (ل.س) - اختياري</label>
                <input className={inputCls} type="number" min={0} dir="ltr" value={cashDiff} onChange={(e) => setCashDiff(e.target.value)} />
              </div>
            )}
            <div>
              <label className="mb-1 block text-sm font-semibold text-stone-700">ملاحظات - اختياري</label>
              <textarea className={inputCls} rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>

            {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-700">{error}</p>}

            <button
              type="submit"
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-3 font-bold text-white hover:bg-emerald-700 disabled:opacity-60"
            >
              {saving ? <Loader2 size={18} className="animate-spin" /> : <Send size={18} />}
              إرسال الاقتراح
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
