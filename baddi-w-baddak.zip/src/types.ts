export type OfferType = 'sell' | 'swap' | 'both' | 'gift';
export type Condition = 'new' | 'like_new' | 'good' | 'fair';
export type ListingStatus = 'active' | 'closed';

export interface Listing {
  id: string;
  created_at: string;
  title: string;
  description: string | null;
  category: string;
  city: string;
  neighborhood: string | null;
  offer_type: OfferType;
  price_syp: number | null;
  swap_preference: string | null;
  accepts_cash_diff: boolean;
  condition: Condition;
  image_url: string | null;
  contact_name: string;
  contact_phone: string;
  status: ListingStatus;
}

export interface SwapOffer {
  id: string;
  created_at: string;
  listing_id: string;
  proposer_name: string;
  proposer_phone: string;
  offered_item_title: string;
  cash_diff_syp: number | null;
  notes: string | null;
  status: 'pending' | 'accepted' | 'rejected' | 'completed';
}

export const SYRIAN_CITIES: string[] = [
  'دمشق',
  'ريف دمشق',
  'حلب',
  'حمص',
  'حماة',
  'اللاذقية',
  'طرطوس',
  'إدلب',
  'دير الزور',
  'الرقة',
  'الحسكة',
  'درعا',
  'السويداء',
  'القنيطرة',
];

export const CATEGORIES: { value: string; label: string }[] = [
  { value: 'books', label: 'كتب ومستلزمات دراسية' },
  { value: 'electronics', label: 'إلكترونيات' },
  { value: 'home', label: 'منزل وأثاث' },
  { value: 'kids', label: 'أطفال وملابس' },
  { value: 'cars_tools', label: 'سيارات وأدوات' },
  { value: 'other', label: 'أخرى' },
];

export const OFFER_TYPES: { value: OfferType; label: string }[] = [
  { value: 'sell', label: 'بيع' },
  { value: 'swap', label: 'للمقايضة' },
  { value: 'both', label: 'بيع أو مقايضة' },
  { value: 'gift', label: 'إهداء مجاني' },
];

export const CONDITIONS: { value: Condition; label: string }[] = [
  { value: 'new', label: 'جديد' },
  { value: 'like_new', label: 'شبه جديد' },
  { value: 'good', label: 'مستعمل بحالة جيدة' },
  { value: 'fair', label: 'مستعمل بحالة مقبولة' },
];
