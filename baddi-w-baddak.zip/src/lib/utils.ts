/** Converts a Syrian phone number into international digits, e.g. 0944 123 456 -> 963944123456 */
export function normalizeSyrianPhone(input: string): string {
  let digits = input.replace(/\D/g, '');
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('963')) return digits;
  if (digits.startsWith('0')) digits = digits.slice(1);
  return `963${digits}`;
}

export function formatSYP(amount: number): string {
  return `${new Intl.NumberFormat('en-US').format(amount)} ل.س`;
}

export function getErrorMessage(err: unknown): string {
  if (err instanceof Error) return err.message;
  if (typeof err === 'object' && err !== null && 'message' in err) {
    return String((err as { message: unknown }).message);
  }
  return 'حدث خطأ غير متوقع، حاول مرة أخرى';
}
