# بدّي وبدّك (Baddi w Baddak)

Barter, secondhand selling and gifting platform for Syria.
React 18 + Vite + Tailwind CSS + TypeScript + Supabase.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env.local` and fill in your Supabase URL and anon key.
3. Run `supabase/schema.sql` in the Supabase SQL editor.
4. `npm run dev`

Without Supabase variables the app runs in demo mode with sample listings.
