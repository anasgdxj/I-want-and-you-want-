-- بدّي وبدّك: Supabase schema
-- Run this whole file in the Supabase SQL editor.

create extension if not exists "pgcrypto";

-- ============ LISTINGS ============
create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  title text not null check (char_length(title) between 2 and 120),
  description text,
  category text not null,
  city text not null,
  neighborhood text,
  offer_type text not null check (offer_type in ('sell', 'swap', 'both', 'gift')),
  price_syp bigint check (price_syp is null or price_syp >= 0),
  swap_preference text,
  accepts_cash_diff boolean not null default false,
  condition text not null default 'good' check (condition in ('new', 'like_new', 'good', 'fair')),
  image_url text,
  contact_name text not null,
  contact_phone text not null,
  status text not null default 'active' check (status in ('active', 'closed'))
);

create index if not exists listings_status_created_idx on public.listings (status, created_at desc);
create index if not exists listings_city_idx on public.listings (city);
create index if not exists listings_category_idx on public.listings (category);

-- ============ SWAP OFFERS ============
create table if not exists public.swap_offers (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  listing_id uuid not null references public.listings (id) on delete cascade,
  proposer_name text not null,
  proposer_phone text not null,
  offered_item_title text not null,
  cash_diff_syp bigint check (cash_diff_syp is null or cash_diff_syp >= 0),
  notes text,
  status text not null default 'pending' check (status in ('pending', 'accepted', 'rejected', 'completed'))
);

create index if not exists swap_offers_listing_idx on public.swap_offers (listing_id);

-- ============ ROW LEVEL SECURITY ============
alter table public.listings enable row level security;
alter table public.swap_offers enable row level security;

drop policy if exists "listings_public_select" on public.listings;
create policy "listings_public_select" on public.listings
  for select to anon, authenticated
  using (true);

drop policy if exists "listings_public_insert" on public.listings;
create policy "listings_public_insert" on public.listings
  for insert to anon, authenticated
  with check (status = 'active');

-- Swap offers: anyone can propose, but offers are not publicly readable
-- (they contain phone numbers). The app inserts without returning rows.
drop policy if exists "swap_offers_public_insert" on public.swap_offers;
create policy "swap_offers_public_insert" on public.swap_offers
  for insert to anon, authenticated
  with check (status = 'pending');

-- ============ STORAGE: listing-images ============
insert into storage.buckets (id, name, public)
values ('listing-images', 'listing-images', true)
on conflict (id) do nothing;

drop policy if exists "listing_images_public_read" on storage.objects;
create policy "listing_images_public_read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'listing-images');

drop policy if exists "listing_images_public_upload" on storage.objects;
create policy "listing_images_public_upload" on storage.objects
  for insert to anon, authenticated
  with check (bucket_id = 'listing-images');
